﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebAPPFarmerCompanion
{
    public static class WebUtil
    {
        public static readonly int ADMIN_ROLE = 1;
        public static readonly int USER_ROLE = 2;
        public static readonly string CURRENT_USER = "CurrentUser";
        public static readonly string MY_COOKIE = "FC328";

    }
}